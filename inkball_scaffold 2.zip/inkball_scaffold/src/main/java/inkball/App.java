package inkball;

import processing.core.PApplet;
import processing.core.PImage;
import processing.core.PVector;
import processing.data.JSONArray;
import processing.data.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class App extends PApplet {

    public static final int CELLSIZE = 32;
    public static final int TOPBAR = 64;
    public static int WIDTH = 576;
    public static int HEIGHT = 640;
    public static final int FPS = 30;

    public String configPath;
    public int spawnInterval;
    public String layoutFile;
    public int level = 2;  // Global level variable to change between levels

    // Offset to move the graphics slightly
    public int yOffset = 65;  // Adjusted to move the graphics up by 1 pixel

    // The layout of the current level
    public String[] currentLayout;

    // Wall and spawner images
    public PImage[] wallImages = new PImage[5];  // Array to hold wall images (0 to 4)
    public PImage[] holeImages = new PImage[5];  // Array to hold hole images (0 to 4)
    public PImage spawnerImage;

    // Timer variables
    public int totalTime = 120;  // Set the total time to 120 seconds
    public int remainingTime;
    public int frameCounter = 0;  // To control the timer
    public int spawnCounter;  // To control the spawn interval countdown

    // List to hold spawner positions
    List<int[]> spawners = new ArrayList<>();

    // List to hold balls
    List<Ball> balls = new ArrayList<>();

    // List to hold upcoming ball images
    List<PImage> upcomingBallImages = new ArrayList<>();  // Store ball images
    Random random = new Random();

    // List to store player-drawn lines
    List<PVector[]> playerLines = new ArrayList<>();

    public App() {
        this.configPath = "config.json";
    }

    @Override
    public void settings() {
        size(WIDTH, HEIGHT);
    }

    @Override
    public void setup() {
        frameRate(FPS);

        // Load wall and spawner images
        wallImages[0] = loadImage("/Users/a/Downloads/inkball_scaffold/src/main/resources/inkball/wall0.png");
        wallImages[1] = loadImage("/Users/a/Downloads/inkball_scaffold/src/main/resources/inkball/wall1.png");
        wallImages[2] = loadImage("/Users/a/Downloads/inkball_scaffold/src/main/resources/inkball/wall2.png");
        wallImages[3] = loadImage("/Users/a/Downloads/inkball_scaffold/src/main/resources/inkball/wall3.png");
        wallImages[4] = loadImage("/Users/a/Downloads/inkball_scaffold/src/main/resources/inkball/wall4.png");
        spawnerImage = loadImage("/Users/a/Downloads/inkball_scaffold/src/main/resources/inkball/entrypoint.png");

        // Load hole images, including hole0.png
        holeImages[0] = loadImage("/Users/a/Downloads/inkball_scaffold/src/main/resources/inkball/hole0.png");
        holeImages[1] = loadImage("/Users/a/Downloads/inkball_scaffold/src/main/resources/inkball/hole1.png");
        holeImages[2] = loadImage("/Users/a/Downloads/inkball_scaffold/src/main/resources/inkball/hole2.png");
        holeImages[3] = loadImage("/Users/a/Downloads/inkball_scaffold/src/main/resources/inkball/hole3.png");
        holeImages[4] = loadImage("/Users/a/Downloads/inkball_scaffold/src/main/resources/inkball/hole4.png");

        loadLevelConfig(level);  // Load the initial level

        // Initialize the timer
        remainingTime = totalTime;  // Start the game with 120 seconds
        spawnCounter = spawnInterval; // Set the spawn counter based on the spawn interval
    }

    public void loadLevelConfig(int levelIndex) {
        JSONObject config = loadJSONObject(configPath);
        JSONArray levels = config.getJSONArray("levels");
        if (levelIndex < levels.size()) {
            JSONObject selectedLevel = levels.getJSONObject(levelIndex);
            layoutFile = selectedLevel.getString("layout");
            spawnInterval = selectedLevel.getInt("spawn_interval");

            // Load upcoming ball images from the configuration
            JSONArray ballsArray = selectedLevel.getJSONArray("balls");
            upcomingBallImages.clear();  // Clear previous upcoming balls
            for (int i = 0; i < ballsArray.size(); i++) {
                String ballColor = ballsArray.getString(i);
                String ballImageFile = getBallImageFilename(ballColor);
                PImage ballImage = loadImage("/Users/a/Downloads/inkball_scaffold/src/main/resources/inkball/" + ballImageFile);
                upcomingBallImages.add(ballImage);  // Add ball image
            }

            // Load the level layout and identify spawner positions
            loadLevel(layoutFile);
        } else {
            System.out.println("No more levels available.");
        }
    }

    public void loadLevel(String layoutFile) {
        currentLayout = loadStrings(layoutFile);  // Load the layout file as a string array
        spawners.clear();  // Clear previous spawner positions
        balls.clear(); // Clear previous balls

        for (int row = 0; row < currentLayout.length; row++) {
            String line = currentLayout[row];
            for (int col = 0; col < line.length(); col++) {
                char cell = line.charAt(col);
                if (cell == 'S') {
                    spawners.add(new int[]{col, row});  // Store the spawner position
                } else if (cell == 'B' && col + 1 < line.length() && Character.isDigit(line.charAt(col + 1))) {
                    int ballType = Character.getNumericValue(line.charAt(col + 1));
                    PImage ballImage = loadImage("/Users/a/Downloads/inkball_scaffold/src/main/resources/inkball/ball" + ballType + ".png");
                    float vx = random.nextBoolean() ? 2 : -2; // Random X velocity
                    float vy = random.nextBoolean() ? 2 : -2; // Random Y velocity
                    balls.add(new Ball(col * CELLSIZE, row * CELLSIZE + yOffset, vx, vy, ballImage, this));  // Pass 'this' as the PApplet instance
                    col++; // Skip the digit to avoid overlapping
                }
            }
        }

        System.out.println("Spawners found: " + spawners.size());
    }

    @Override
    public void keyPressed() {
        if (key == '0') {
            level = 0;
            loadLevelConfig(level);
        } else if (key == '1') {
            level = 1;
            loadLevelConfig(level);
        } else if (key == '2') {
            level = 2;
            loadLevelConfig(level);
        }
    }

    @Override
    public void mouseDragged() {
        PVector startPoint = new PVector(mouseX, mouseY);
        PVector endPoint = new PVector(pmouseX, pmouseY);  // Previous mouse position
        playerLines.add(new PVector[]{startPoint, endPoint});
    }

    @Override
    public void draw() {
        background(255);  // Clear the screen with white

        frameCounter++;
        if (frameCounter >= FPS) {  // FPS is set to 30, so 30 frames = 1 second
            remainingTime--;
            frameCounter = 0;  // Reset the frame counter
        }

        if (remainingTime <= 0) {
            fill(0);
            textSize(32);
            text("Game Over", WIDTH / 2 - 100, HEIGHT / 2);
            noLoop();  // Stop the game loop when the timer reaches 0
            return;  // Exit early to prevent drawing when game is over
        }

        drawWallsAndHoles();  // Now includes holes
        drawSpawners();
        updateAndDisplayBalls();  // Update and display balls

        displayTimer();
        displayUpcomingBalls();

        stroke(0);
        strokeWeight(10);
        for (PVector[] line : playerLines) {
            line(line[0].x, line[0].y, line[1].x, line[1].y);
        }
    }

    public void drawWallsAndHoles() {
        for (int row = 0; row < currentLayout.length; row++) {
            String line = currentLayout[row];
            for (int col = 0; col < line.length(); col++) {
                char cell = line.charAt(col);
                if (cell == 'X') {
                    image(wallImages[0], col * CELLSIZE, row * CELLSIZE + yOffset);  // Draw wall
                } else if (Character.isDigit(cell)) {
                    int wallType = Character.getNumericValue(cell);
                    if (wallType >= 1 && wallType <= 4) {
                        image(wallImages[wallType], col * CELLSIZE, row * CELLSIZE + yOffset);  // Draw specific wall type
                    }
                } else if (cell == 'H' && col + 1 < line.length() && Character.isDigit(line.charAt(col + 1))) {
                    int holeType = Character.getNumericValue(line.charAt(col + 1));
                    if (holeType >= 0 && holeType <= 4) {
                        image(holeImages[holeType], col * CELLSIZE, row * CELLSIZE + yOffset);  // Draw the corresponding hole image
                        col++;  // Skip the next digit
                    }
                }
            }
        }
    }

    public void drawSpawners() {
        for (int[] spawner : spawners) {
            image(spawnerImage, spawner[0] * CELLSIZE, spawner[1] * CELLSIZE + yOffset);
        }
    }

    public void updateAndDisplayBalls() {
        for (int i = balls.size() - 1; i >= 0; i--) { // Reverse loop to remove balls if needed
            Ball ball = balls.get(i);
            ball.update();  // Update the ball's position
            ball.handleLineCollision(playerLines);  // Handle player-drawn line collisions
            ball.handleWallCollision(currentLayout);  // Handle the wall collision with improved movement

            if (checkHoleAbsorption(ball)) {
                if (!respawnBallAtSpawner(ball)) {
                    balls.remove(i);  // If it's not a grey ball or cannot be respawned, absorb the ball (remove it)
                }
            } else {
                ball.display(this);  // Draw the ball if not absorbed
            }
        }

        spawnCounter--;
        if (spawnCounter <= 0 && !upcomingBallImages.isEmpty()) {
            int randomSpawnerIndex = random.nextInt(spawners.size());
            int[] spawner = spawners.get(randomSpawnerIndex);
            int spawnX = spawner[0] * CELLSIZE;
            int spawnY = spawner[1] * CELLSIZE + yOffset;
            PImage nextBallImage = upcomingBallImages.remove(0);  // Get the next ball image to spawn

            if (nextBallImage == null) {
                System.out.println("Error: Image not found for upcoming ball.");
            } else {
                float vx = random.nextBoolean() ? 2 : -2; // Random X velocity
                float vy = random.nextBoolean() ? 2 : -2; // Random Y velocity
                balls.add(new Ball(spawnX, spawnY, vx, vy, nextBallImage, this));  // Spawn the ball
            }
            spawnCounter = spawnInterval * FPS;  // Reset the spawn counter
        }
    }

    public boolean respawnBallAtSpawner(Ball ball) {
        String ballColor = getBallColorFromImage(ball.image);
        if (ballColor != null && ballColor.equals("grey")) {
            int randomSpawnerIndex = random.nextInt(spawners.size());
            int[] spawner = spawners.get(randomSpawnerIndex);
            ball.x = spawner[0] * CELLSIZE;
            ball.y = spawner[1] * CELLSIZE + yOffset;
            return true;
        }
        return false;
    }

    public void displayTimer() {
        fill(0);
        textSize(18);
        text("Time: " + remainingTime, WIDTH - 150, 50);
    }

    public void displayUpcomingBalls() {
        for (int i = 0; i < min(5, upcomingBallImages.size()); i++) {
            PImage ballImage = upcomingBallImages.get(i);
            image(ballImage, 150 + (i * 40), 20, 32, 32);  // Display the ball image in the top bar
        }
    }

    public boolean checkHoleAbsorption(Ball ball) {
        for (int row = 0; row < currentLayout.length; row++) {
            String line = currentLayout[row];
            for (int col = 0; col < line.length(); col++) {
                char cell = line.charAt(col);
                if (cell == 'H' && col + 1 < line.length() && Character.isDigit(line.charAt(col + 1))) {
                    int holeType = Character.getNumericValue(line.charAt(col + 1));
                    if (holeType >= 0 && holeType <= 4) {
                        float holeX = col * CELLSIZE;
                        float holeY = row * CELLSIZE + yOffset;
                        if (ball.x + CELLSIZE > holeX && ball.x < holeX + CELLSIZE &&
                            ball.y + CELLSIZE > holeY && ball.y < holeY + CELLSIZE) {
                            if (holeType == 0) {
                                return true;  // Mark for respawn
                            } else {
                                String ballColor = getBallColorFromImage(ball.image);
                                if (ballColor != null && ballColor.equals(getHoleColor(holeType))) {
                                    return true;  // Ball is absorbed by matching hole
                                }
                            }
                        }
                    }
                }
            }
        }
        return false;
    }

    public String getHoleColor(int holeType) {
        switch (holeType) {
            case 1: return "orange";
            case 2: return "blue";
            case 3: return "green";
            case 4: return "yellow";
            default: return null;
        }
    }

    public String getBallColorFromImage(PImage ballImage) {
        if (ballImage == null) return null;
        if (ballImage == loadImage("/Users/a/Downloads/inkball_scaffold/src/main/resources/inkball/ball0.png")) return "grey";
        if (ballImage == loadImage("/Users/a/Downloads/inkball_scaffold/src/main/resources/inkball/ball1.png")) return "orange";
        if (ballImage == loadImage("/Users/a/Downloads/inkball_scaffold/src/main/resources/inkball/ball2.png")) return "blue";
        if (ballImage == loadImage("/Users/a/Downloads/inkball_scaffold/src/main/resources/inkball/ball3.png")) return "green";
        if (ballImage == loadImage("/Users/a/Downloads/inkball_scaffold/src/main/resources/inkball/ball4.png")) return "yellow";
        return null;
    }

    public String getBallImageFilename(String ballType) {
        switch (ballType) {
            case "grey":
                return "ball0.png";
            case "orange":
                return "ball1.png";
            case "blue":
                return "ball2.png";
            case "green":
                return "ball3.png";
            case "yellow":
                return "ball4.png";
            default:
                System.out.println("Unknown ball type: " + ballType);
                return "default_ball.png";
        }
    }

    public static void main(String[] args) {
        PApplet.main("inkball.App");
    }
}

// Ball class definition
class Ball {
    float x, y;  // Position of the ball
    float vx, vy;  // Velocity of the ball
    PImage image;  // Image of the ball
    PApplet applet;  // Reference to PApplet for random function

    Ball(float x, float y, float vx, float vy, PImage image, PApplet applet) {
        this.x = x;
        this.y = y;
        this.vx = vx;
        this.vy = vy;
        this.image = image;
        this.applet = applet;
    }

    void update() {
        x += vx;
        y += vy;
    }

    void handleLineCollision(List<PVector[]> playerLines) {
        for (PVector[] line : playerLines) {
            PVector p1 = line[0];
            PVector p2 = line[1];

            PVector normal1 = new PVector(p2.y - p1.y, p1.x - p2.x);
            PVector normal2 = new PVector(p1.y - p2.y, p2.x - p1.x);

            normal1.normalize();
            normal2.normalize();

            PVector midpoint = PVector.add(p1, p2).div(2);
            PVector closestNormal = PVector.dist(midpoint, new PVector(x, y)) < PVector.dist(midpoint.add(normal1), new PVector(x, y)) ? normal1 : normal2;

            if (PVector.dist(midpoint, new PVector(x, y)) < App.CELLSIZE) {
                PVector v = new PVector(vx, vy);
                float dotProduct = v.dot(closestNormal);
                PVector reflection = PVector.sub(v, PVector.mult(closestNormal, 2 * dotProduct));
                vx = reflection.x;
                vy = reflection.y;
            }
        }
    }

    void display(PApplet applet) {
        applet.image(image, x, y);
    }

    void handleWallCollision(String[] layout) {
        // Calculate which row and column the ball is in based on its current position
        int col = (int) (x / App.CELLSIZE);
        int row = (int) ((y - App.TOPBAR) / App.CELLSIZE);
    
        // Boundary checks to prevent index out of bounds
        if (col < 0 || col >= layout[0].length() || row < 0 || row >= layout.length) {
            return;  // If the ball is out of bounds, skip handling
        }
    
        // Get the current character from the layout
        char cell = layout[row].charAt(col);
    
        // List of valid wall characters (including other colored walls, e.g., '1', '2', '3', '4')
        if (cell == 'X' || cell == '1' || cell == '2' || cell == '3' || cell == '4') {
    
            // Store the previous position
            float prevX = x - vx;
            float prevY = y - vy;
    
            // Calculate the previous row and column before the ball moved
            int prevCol = (int) (prevX / App.CELLSIZE);
            int prevRow = (int) ((prevY - App.TOPBAR) / App.CELLSIZE);
    
            // Smoothing factor for fine-tuning collision detection
            float smoothingFactor = 0.1f;  // Adjust the threshold for smoother collision
    
            // Handle horizontal collision (left-right)
            if (prevCol != col) {
                vx *= -1;  // Reflect horizontal velocity
                if (vx > 0) {
                    x = col * App.CELLSIZE - App.CELLSIZE + smoothingFactor;  // Move the ball to the left of the wall
                } else {
                    x = (col + 1) * App.CELLSIZE - smoothingFactor;  // Move the ball to the right of the wall
                }
            }
    
            // Handle vertical collision (up-down)
            if (prevRow != row) {
                vy *= -1;  // Reflect vertical velocity
                if (vy > 0) {
                    y = row * App.CELLSIZE - App.CELLSIZE + smoothingFactor;  // Move the ball above the wall
                } else {
                    y = (row + 1) * App.CELLSIZE - smoothingFactor;  // Move the ball below the wall
                }
            }
        }
    
        // Reflect at the boundaries of the game window (optional)
        if (x <= 0 || x + App.CELLSIZE >= App.WIDTH) {
            vx *= -1;  // Reflect horizontally at window edges
            x = (x <= 0) ? 0 : App.WIDTH - App.CELLSIZE;  // Adjust position to stay within bounds
        }
        if (y <= App.TOPBAR || y + App.CELLSIZE >= App.HEIGHT) {
            vy *= -1;  // Reflect vertically at window edges
            y = (y <= App.TOPBAR) ? App.TOPBAR : App.HEIGHT - App.CELLSIZE;  // Adjust position to stay within bounds
        }
    }
}    